

<?php $__env->startSection('title', 'PROVEICYDET'); ?>

<?php $__env->startSection('content'); ?>

<div class="flex items-center justify-center mt-[10%] flex-col">
                <h1 class="font-bold text-3xl">ESTAMOS EN MANTENIMIENTO</h1>
                <h2>Disculpe las molestias</h2>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\COVEICYDET\resources\views/screens/mantenimiento.blade.php ENDPATH**/ ?>