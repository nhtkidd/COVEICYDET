@extends('layout.layout')

@section('title', 'PROVEICYDET')

@section('content')

<div class="flex items-center justify-center mt-[10%] flex-col">
                <h1 class="font-bold text-3xl">Estamos en mantenimiento</h1>
                <h2>Disculpe las molestias</h2>
        </div>

@endsection
