<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <!-- favicon    -->
    <!-- styles -->
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>

<body class="bg-spaceGray">
    <!--header  -->
    <header class="bg-gold w-100 h-44 ">
        <div class="bg-spaceGray w-full h-8">
        </div>
        <div class="bg-white w-auto h-28 flex justify-center items-center">
            <img class=" h-[40%] md:h-[70%] "  src="<?php echo e(URL('img/Header.png')); ?>">
        </div>
        

    </header>
    <!-- nav -->

    <?php echo $__env->yieldContent('content'); ?>

    <!-- footer -->
    <!-- scripts -->
    <script src="https://cdn.tailwindcss.com"></script>


</body>

</html><?php /**PATH C:\xampp\htdocs\COVEICYDET\resources\views/layout/layout.blade.php ENDPATH**/ ?>