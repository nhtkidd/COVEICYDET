

<?php $__env->startSection('title', 'Administrador'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex flex-row-reverse py-3 border-b-4 border-[#AA983F]">
                
    <a class="px-5 font-bold text-lg text-red-800" href="<?php echo e(route('proveicydet.destroy')); ?>">Cerrar sesión</a>
    <h1 class="px-5 font-bold text-lg"> <?php echo e(auth()->user()->name); ?></h1>
</div>
    <h1>BIENVENIDO AL TABLERO DE ADMINISTRADOR</h1>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\COVEICYDET\resources\views/admin/index.blade.php ENDPATH**/ ?>