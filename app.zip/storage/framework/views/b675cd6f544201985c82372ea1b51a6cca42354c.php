

<?php $__env->startSection('title', 'Confirmacion de registro'); ?>

<?php $__env->startSection('content'); ?>

    <div class="flex items-center justify-center">

        <div class="w-[85%] md:w-[60%] h-auto text-center p-10 2xl:mt-20">
            <h2 class="text-3xl font-bold p-4">Registro exitoso</h2>
            <h5>Por favor, proceda a iniciar sesión para continuar</h5>
            <br>
            <a href="<?php echo e(route('proveicydet.login')); ?>" class="px-6 py-2 w-auto h-auto bg-gold hover:bg-[#998b47] rounded-lg text-lg font-semibold text-white">Continuar</a>
        </div>
        


    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\COVEICYDET\resources\views/messages/success.blade.php ENDPATH**/ ?>