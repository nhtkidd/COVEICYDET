

<?php $__env->startSection('title', 'Inicia sesión'); ?>

<?php $__env->startSection('content'); ?>

    <div id="wrapper" class="flex flex-wrap w-screen ">
        <div id="1" class="w-full hidden lg:flex items-center justify-center lg:w-1/2 lg:h-[100vh-176px] "
            style="height: calc(100vh -  176px )">
            <img class=" pt-4 pb-10  h-auto md:w-[40%] lg:w-[64%] "  src="<?php echo e(URL('img/Consulta.jpg')); ?>">
            
        </div>
        <div id="2" class="w-full lg:w-1/2 flex mt-[10%] lg:mt-0 lg:items-center justify-center "
         >
            <div class="bg-white w-[90%] h-auto lg:w-[70%] lg:h-[90%] 2xl:h-[65%] rounded-br-large">
                <form action="<?php echo e(route('proveicydet.compare')); ?>" method="post" class="p-10">
                    <?php echo csrf_field(); ?>
                    <h1 class="text-2xl 2xl:text-4xl font-bold">Olvide mi contraseña</h1>
                    <div class="my-4">
                        <label class="block text-gray-700 text-sm 2xl:text-xl font-bold mb-2" for="email">
                            Email
                        </label>
                        <input
                            class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                            id="email" type="email" placeholder="Email" name="email" required>
                    </div>


                    <div class="mb-3">
                        <button
                            class="bg-[#635C44] hover:bg-[#484332] text-white 2xl:text-xl font-bold w-full py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                            type="submit">
                            Iniciar sesión
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\COVEICYDET\resources\views/screens/forgotpassword.blade.php ENDPATH**/ ?>